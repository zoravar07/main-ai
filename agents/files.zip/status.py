"""Live data for the Zopro dashboard.

Everything here comes from a real source. Where a source is unavailable or a
table has an unexpected shape, the field returns None or an empty list — the UI
shows that as unknown. Nothing is estimated or filled in.
"""

import os
import json
import sqlite3
import requests
from datetime import datetime

ZMONEY_DB = "/Users/zoravarsingh/Desktop/z money agent/data/z_money.db"

SUPABASE_URL = (os.environ.get("VITE_SUPABASE_URL") or "").rstrip("/")
SUPABASE_KEY = os.environ.get("VITE_SUPABASE_ANON_KEY", "")

# Kuala Lumpur
LAT, LON = 3.139, 101.6869

# Published per-million-token prices. Used only to turn recorded token counts
# into an approximate cost — the tokens themselves are measured, the rate is not.
RATES = {
    "haiku": (0.80, 4.00),
    "sonnet": (3.00, 15.00),
    "opus": (15.00, 75.00),
}


def _q(sql, params=()):
    try:
        conn = sqlite3.connect(f"file:{ZMONEY_DB}?mode=ro", uri=True)
        cur = conn.execute(sql, params)
        cols = [d[0] for d in cur.description]
        rows = [dict(zip(cols, r)) for r in cur.fetchall()]
        conn.close()
        return rows
    except Exception:
        return None


def _cost(model, tin, tout):
    if not model or tin is None or tout is None:
        return None
    m = model.lower()
    for k, (rin, rout) in RATES.items():
        if k in m:
            return (tin / 1_000_000) * rin + (tout / 1_000_000) * rout
    return None


def zmoney():
    runs = _q("SELECT id, started_at, finished_at, status FROM runs ORDER BY id DESC LIMIT 8")
    if runs is None:
        return {"available": False}
    if not runs:
        return {"available": True, "runs": [], "latest": None}

    # Cost per run from recorded token usage.
    tok = _q("SELECT run_id, model, SUM(input_tokens) ti, SUM(output_tokens) tout_sum "
             "FROM research_outputs GROUP BY run_id, model") or []
    per_run = {}
    for r in tok:
        c = _cost(r.get("model"), r.get("ti"), r.get("tout_sum"))
        if c is not None:
            per_run[r["run_id"]] = per_run.get(r["run_id"], 0) + c

    for r in runs:
        r["cost"] = per_run.get(r["id"])
        m = _q("SELECT COUNT(*) c FROM research_outputs WHERE run_id = ?", (r["id"],))
        s = _q("SELECT COUNT(*) c FROM conviction WHERE run_id = ?", (r["id"],))
        r["memos"] = m[0]["c"] if m else None
        r["scores"] = s[0]["c"] if s else None
        r["verified"] = (r["memos"] is not None and r["scores"] is not None
                         and r["memos"] >= r["scores"])

    latest = runs[0]
    rid = latest["id"]

    proposals = _q(
        "SELECT ticker, action, quantity, limit_price, est_cost, conviction, "
        "trigger_type, status, rationale FROM proposals WHERE run_id = ? ORDER BY ticker",
        (rid,)) or []

    positions = _q(
        "SELECT ticker, qty, avg_cost, conviction_at_entry, peak_price_since_activation, "
        "last_verified_at FROM positions ORDER BY ticker") or []

    conviction = _q(
        "SELECT ticker, score FROM conviction WHERE run_id = ? ORDER BY score DESC",
        (rid,)) or []

    watchlist = _q("SELECT * FROM watchlist_items LIMIT 30")
    risk = _q("SELECT type, detail_json FROM risk_events WHERE run_id = ? LIMIT 12", (rid,)) or []
    nav = _q("SELECT * FROM nav_snapshots ORDER BY rowid DESC LIMIT 1")

    return {
        "available": True,
        "latest": latest,
        "runs": runs,
        "proposals": proposals,
        "positions": positions,
        "conviction": conviction,
        "watchlist": watchlist if watchlist is not None else [],
        "risk_events": risk,
        "nav": nav[0] if nav else None,
    }


def _sb_token():
    email = os.environ.get("HUNGRYVAR_EMAIL")
    password = os.environ.get("HUNGRYVAR_PASSWORD")
    if not (SUPABASE_URL and SUPABASE_KEY and email and password):
        return None
    try:
        r = requests.post(
            f"{SUPABASE_URL}/auth/v1/token?grant_type=password",
            headers={"apikey": SUPABASE_KEY, "Content-Type": "application/json"},
            json={"email": email, "password": password}, timeout=12)
        return r.json()["access_token"] if r.status_code == 200 else None
    except Exception:
        return None


def _sb(token, table, params):
    try:
        r = requests.get(
            f"{SUPABASE_URL}/rest/v1/{table}",
            headers={"apikey": SUPABASE_KEY, "Authorization": f"Bearer {token}"},
            params=params, timeout=12)
        return r.json() if r.status_code == 200 else None
    except Exception:
        return None


def hungryvar():
    token = _sb_token()
    if not token:
        return {"available": False}

    weeks = _sb(token, "weeks",
                "select=*&status=neq.archived&order=week_start.desc&limit=1") or []
    week = weeks[0] if weeks else None

    plan = week.get("plan") if week else None
    if isinstance(plan, str):
        try:
            plan = json.loads(plan)
        except Exception:
            plan = None

    return {
        "available": True,
        "week": {k: v for k, v in (week or {}).items() if k != "plan"} if week else None,
        "plan": plan,
        "pantry": _sb(token, "pantry", "select=*&limit=60") or [],
        "staples": _sb(token, "staples", "select=*&limit=60") or [],
        "supplements": _sb(token, "supplements", "select=*&limit=40") or [],
        "shops": _sb(token, "grocery_shops", "select=*&limit=20") or [],
        "logs": _sb(token, "meal_logs", "select=*&order=id.desc&limit=20") or [],
    }


def weather():
    try:
        r = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": LAT, "longitude": LON,
                "current": "temperature_2m,relative_humidity_2m,apparent_temperature,"
                           "precipitation,weather_code",
                "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max",
                "timezone": "Asia/Kuala_Lumpur", "forecast_days": 3,
            }, timeout=12)
        if r.status_code != 200:
            return {"available": False}
        d = r.json()
        return {"available": True, "place": "Kuala Lumpur",
                "current": d.get("current"), "daily": d.get("daily")}
    except Exception:
        return {"available": False}


def full_status():
    return {
        "time": datetime.now().isoformat(),
        "zmoney": zmoney(),
        "hungryvar": hungryvar(),
        "weather": weather(),
    }

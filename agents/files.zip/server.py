import io
import os
import contextlib
from pathlib import Path
from dotenv import load_dotenv

# Must run before importing zopro — the agent modules read these at import time,
# and launchd does not source your shell profile.
load_dotenv(Path(__file__).parent / ".env")

from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import tempfile

from zopro import classify, ask_internship_buddy, ask_zmoney, ask_hungryvar, answer_directly

app = FastAPI(title="Zopro")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

SPECIALISTS = {
    "internship": ("Internship & Career Assistant", ask_internship_buddy),
    "zmoney": ("Zmoney Analyst", ask_zmoney),
    "hungryvar": ("Hungryvar Assistant", ask_hungryvar),
}


class Question(BaseModel):
    question: str


@app.get("/health")
def health():
    return {"ok": True}


@app.get("/status")
def status():
    """Live figures for the dashboard. Real sources only — anything
    unreachable reports available: false rather than a placeholder."""
    from status import full_status
    return full_status()


@app.post("/transcribe")
async def transcribe(audio: UploadFile = File(...)):
    """Local speech to text. Needs faster-whisper:
        pip install faster-whisper
    Audio never leaves the machine."""
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        return {"error": "Voice needs faster-whisper. Run: pip install faster-whisper"}

    global _whisper
    try:
        _whisper
    except NameError:
        _whisper = None

    if _whisper is None:
        _whisper = WhisperModel("base.en", device="cpu", compute_type="int8")

    with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as f:
        f.write(await audio.read())
        path = f.name

    try:
        segments, _ = _whisper.transcribe(path, beam_size=1)
        return {"text": " ".join(s.text for s in segments).strip()}
    except Exception as e:
        return {"error": f"Transcription failed: {e}"}
    finally:
        os.unlink(path)


@app.post("/ask")
def ask(q: Question):
    """Classify, dispatch, and return the answer plus which specialist handled it.
    The route is returned separately so the UI can show delegation as it happens."""
    question = q.question.strip()
    if not question:
        return {"error": "Empty question."}

    try:
        route = classify(question)
    except Exception as e:
        return {"error": f"Classifier failed: {e}"}

    name, handler = SPECIALISTS.get(route, ("Zopro", answer_directly))

    # CrewAI prints verbose agent output to stdout; swallow it so it doesn't
    # interleave with the server log.
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            answer = handler(question)
    except Exception as e:
        return {"route": route, "specialist": name, "error": str(e)}

    return {"route": route, "specialist": name, "answer": str(answer)}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8420)
